
let nome: string;

nome = "Olá mundo";
nome = "Luisa";



//  Arrays e Tuplas


let lista: number[];

lista = [2, 3]

let listaDois: boolean[];

lista = [true,false,true,true];

// Ou 

let listaOutraForma = Array<boolean>
  lista = [true, false, true, true];


// Tupla

let aluno: [string, number, boolean];

aluno = ["daniel", 24, true];
